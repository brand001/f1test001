/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, type FC } from 'react';
import { Client } from '@amityco/ts-sdk-react-native';
import type { AuthContextInterface } from '../types/auth.interface';
import { Alert } from 'react-native';
import type { IAmityUIkitProvider } from './amity-ui-kit-provider';
import connectionStateSlice from '../redux/slices/ConnectionStateSlice';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../redux/store';

export const AuthContext = React.createContext<AuthContextInterface>({
  client: {},
  isConnecting: false,
  error: '',
  login: () => {},
  logout: () => {},
  isConnected: false,
  sessionState: '',
  apiRegion: 'sg',
  authToken: '',
  language: 'en',
});

export const AuthContextProvider: FC<
  Omit<IAmityUIkitProvider, 'roleConfig'>
> = ({
  userId,
  displayName,
  apiKey,
  apiRegion,
  apiEndpoint,
  children,
  authToken,
  language,
}) => {
  const dispatch = useDispatch();
  const [error, setError] = useState('');
  const [isConnecting, setLoading] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [sessionState, setSessionState] = useState('');
  const { connectionState } = useSelector(
    (state: RootState) => state.connectionState
  );

  const client: Amity.Client = Client.createClient(apiKey, apiRegion, {
    apiEndpoint: { http: apiEndpoint },
  });

  const sessionHandler: Amity.SessionHandler = {
    sessionWillRenewAccessToken(renewal) {
      renewal.renew();
    },
  };

  useEffect(() => {
    const unsubscribe = Client.onRTEConnectionStateChange((state) => {
      dispatch(
        connectionStateSlice.actions.updateConnectionState({
          connectionState: state,
        })
      );
    });

    return () => {
      unsubscribe?.();
    };
  }, [dispatch]);

  useEffect(() => {
    if (connectionState === 'disconnected') {
      Client.getActiveClient().mqtt?.reconnect();
    }
  }, [connectionState]);

  useEffect(() => {
    return Client.onSessionStateChange((state: Amity.SessionStates) =>
      setSessionState(state)
    );
  }, []);

  const startSync = () => {
    Client.enableUnreadCount();
  };
  useEffect(() => {
    if (sessionState === 'established') {
      startSync();
      setIsConnected(true);
    }
  }, [sessionState]);

  const handleConnect = async () => {
    let loginParam;

    loginParam = {
      userId: userId,
      displayName: displayName, // optional
    };
    if ((authToken as string)?.length > 0) {
      loginParam = { ...loginParam, authToken: authToken };
    }
    const response = await Client.login(loginParam, sessionHandler);

    if (response) {
      console.log('response:', response);
    }
  };

  const login = async () => {
    setError('');
    setLoading(true);
    try {
      handleConnect();
    } catch (e) {
      const errorText =
        (e as Error)?.message ?? 'Error while handling request!';

      setError(errorText);
      throw error;
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    login();
  }, [userId]);

  // TODO

  const logout = async () => {
    try {
      Client.stopUnreadSync();
      await Client.logout();
    } catch (e) {
      const errorText =
        (e as Error)?.message ?? 'Error while handling request!';

      Alert.alert(errorText);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        error,
        isConnecting,
        login,
        client,
        logout,
        isConnected,
        sessionState,
        apiRegion: (apiRegion as string).toLowerCase(),
        language,
      }}
    >
      {children}
    </AuthContext.Provider>
    //
  );
};
export default AuthContextProvider;
