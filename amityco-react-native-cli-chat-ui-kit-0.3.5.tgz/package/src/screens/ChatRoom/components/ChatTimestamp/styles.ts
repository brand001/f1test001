import { StyleSheet } from 'react-native';
import { useTheme } from "react-native-paper";
import type { MyMD3Theme } from "../../../../providers/amity-ui-kit-provider";

export const useStyles = () => {
  const theme = useTheme() as MyMD3Theme;

  const styles = StyleSheet.create({
    chatTimestamp: {
      fontSize: 13,
      color: theme.colors.baseShade2,
      marginTop: 4,
    }
  });

  return styles;
}


