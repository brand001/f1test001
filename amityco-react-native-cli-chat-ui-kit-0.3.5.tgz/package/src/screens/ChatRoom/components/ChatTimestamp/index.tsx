import moment from 'moment';
import React, { useEffect, useState } from 'react';
import { useStyles } from './styles';
import { Text } from 'react-native';
import { MessageRepository } from '@amityco/ts-sdk-react-native';

interface IMessage {
  _id: string;
  text?: string;
  createdAt: string;
  editedAt: string;
  user: {
    _id: string;
    name: string;
    avatar: string;
  };
  image?: string;
  messageType: string;
  isPending?: boolean;
  isDeleted: boolean;
}

interface Props {
  message: IMessage,
  isUserChat: boolean
}

function ChatTimestamp({ message, isUserChat }: Props) {
  const styles = useStyles()

  const [isFlagged, setIsFlagged] = useState<boolean>(false)

  const checkIsFlagged = async () => {
    const isFlaggedByMe = await MessageRepository.isMessageFlaggedByMe(message._id)

    setIsFlagged(isFlaggedByMe)
  }

  useEffect(() => {
    checkIsFlagged()
  }, [checkIsFlagged])

  return (
    <Text
      style={[
        styles.chatTimestamp,
        {
          alignSelf: isUserChat ? 'flex-end' : 'flex-start',
        },
      ]}
    >
      {!isFlagged && (message.createdAt != message.editedAt) ? 'Edited ·' : ''}{' '}
      {moment(message.createdAt != message.editedAt ? message.editedAt : message.createdAt).format('hh:mm A')}
    </Text>
  )
}

export default ChatTimestamp