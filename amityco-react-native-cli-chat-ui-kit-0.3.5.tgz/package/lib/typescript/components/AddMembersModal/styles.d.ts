export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
        paddingTop: number;
    };
    header: {
        padding: number;
        paddingTop: number;
        zIndex: number;
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "space-between";
    };
    closeButton: {
        padding: number;
    };
    headerTextContainer: {
        flex: number;
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
    };
    headerText: {
        fontWeight: "600";
        fontSize: number;
        textAlign: "center";
        color: string;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginBottom: number;
        backgroundColor: string;
    };
    categoryIcon: {
        alignItems: "center";
    };
    LoadingIndicator: {
        paddingVertical: number;
    };
    headerWrap: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
    };
    inputWrap: {
        height: number;
        marginHorizontal: number;
        backgroundColor: string;
        paddingHorizontal: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "space-between";
        marginBottom: number;
        display: "flex";
        alignItems: "center";
    };
    input: {
        flex: number;
        marginHorizontal: number;
        color: string;
    };
    cancelBtn: {
        marginRight: number;
    };
    searchScrollList: {
        paddingBottom: number;
        marginTop: number;
    };
    doneText: {
        color: string;
    };
    disabledDone: {
        opacity: number;
    };
    sectionItem: {
        flex: number;
    };
};
//# sourceMappingURL=styles.d.ts.map