import { PayloadAction } from '@reduxjs/toolkit';
type ConnectionState = {
    connectionState: Amity.RTEConnectionState;
};
declare const connectionStateSlice: import("@reduxjs/toolkit").Slice<ConnectionState, {
    updateConnectionState: (_: import("immer").WritableDraft<ConnectionState>, action: PayloadAction<ConnectionState>) => ConnectionState;
}, "connectionStateSlice", "connectionStateSlice", import("@reduxjs/toolkit").SliceSelectors<ConnectionState>>;
export default connectionStateSlice;
//# sourceMappingURL=ConnectionStateSlice.d.ts.map