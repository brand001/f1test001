import React from 'react';
export declare const DownloadIcon: ({ color }: {
    color?: string;
}) => React.JSX.Element;
//# sourceMappingURL=DownloadIcon.d.ts.map