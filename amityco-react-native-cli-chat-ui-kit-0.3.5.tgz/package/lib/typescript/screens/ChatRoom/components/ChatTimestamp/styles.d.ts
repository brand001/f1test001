export declare const useStyles: () => {
    chatTimestamp: {
        fontSize: number;
        color: string;
        marginTop: number;
    };
};
//# sourceMappingURL=styles.d.ts.map