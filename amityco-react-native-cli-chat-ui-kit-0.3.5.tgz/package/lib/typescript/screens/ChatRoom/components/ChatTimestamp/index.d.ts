import React from 'react';
interface IMessage {
    _id: string;
    text?: string;
    createdAt: string;
    editedAt: string;
    user: {
        _id: string;
        name: string;
        avatar: string;
    };
    image?: string;
    messageType: string;
    isPending?: boolean;
    isDeleted: boolean;
}
interface Props {
    message: IMessage;
    isUserChat: boolean;
}
declare function ChatTimestamp({ message, isUserChat }: Props): React.JSX.Element;
export default ChatTimestamp;
//# sourceMappingURL=index.d.ts.map